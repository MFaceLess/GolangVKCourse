package main

import (
	"fmt"
	"log"
	"net/http"
	"os"

	"redditclone/pkg/handlers"
	"redditclone/pkg/middleware"
	"redditclone/pkg/post"
	"redditclone/pkg/user"

	"github.com/gorilla/mux"
	"go.uber.org/zap"
)

func main() {
	zapLogger, err := zap.NewProduction()
	if err != nil {
		log.Fatalf("Ошибка при создании логера zap: %s", err.Error())
	}
	defer zapLogger.Sync()
	logger := zapLogger.Sugar()

	userRepo := user.NewMemoryRepo()
	postRepo := post.NewMemoryRepo()

	userHandler := &handlers.UserHandler{
		Logger:   logger,
		UserRepo: userRepo,
	}

	postHandler := &handlers.PostHandler{
		Logger:   logger,
		PostRepo: postRepo,
	}

	r := mux.NewRouter()

	s := http.StripPrefix("/static/", http.FileServer(http.Dir("../../static")))
	r.PathPrefix("/static/").Handler(s)
	r.Handle("/", http.FileServer(http.Dir("../../static/html")))

	r.HandleFunc("/api/login", userHandler.Login).Methods(http.MethodPost)
	r.HandleFunc("/api/register", userHandler.Register).Methods(http.MethodPost)
	r.HandleFunc("/api/posts/", postHandler.GetAllPosts).Methods(http.MethodGet)
	r.HandleFunc("/api/posts/{CATEGORY_NAME}", postHandler.GetPostByCategory).Methods(http.MethodGet)
	r.HandleFunc("/api/post/{POST_ID}", postHandler.GetPostByID).Methods(http.MethodGet)
	r.HandleFunc("/api/user/{USER_LOGIN}", postHandler.GetPostsByUsername).Methods(http.MethodGet)

	protectedRouter := r.PathPrefix("/api").Subrouter()
	protectedRouter.Use(middleware.JWTMiddleWare)

	protectedRouter.HandleFunc("/posts", postHandler.AddPost).Methods(http.MethodPost)
	protectedRouter.HandleFunc("/post/{POST_ID}", postHandler.DeletePost).Methods(http.MethodDelete)
	protectedRouter.HandleFunc("/post/{POST_ID}", postHandler.AddComment).Methods(http.MethodPost)
	protectedRouter.HandleFunc("/post/{POST_ID}/{COMMENT_ID}", postHandler.DeleteComment).Methods(http.MethodDelete)

	port := os.Getenv("port")
	if port == "" {
		port = "8080"
	}

	fmt.Printf("starting server at :%s\n", port)
	http.ListenAndServe(":"+port, r)
}
