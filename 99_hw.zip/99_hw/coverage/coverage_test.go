package main

import (
	"net/http"
	"net/http/httptest"
	"testing"
	"reflect"
	"time"
)

type TestCase struct {
	AccessToken string
	Request SearchRequest
	Result  *SearchResponse
	IsError bool
	TextError string
}


func MockServer(w http.ResponseWriter, r *http.Request) {
	token := r.Header.Get("AccessToken")
	if token == "timeout_error_testing" {
		time.Sleep(2 * time.Second)
		w.WriteHeader(http.StatusOK)
		return
	}
	if token == "unknownConnectionError" {
		hijacker, ok := w.(http.Hijacker)
		if !ok {

		}
		
	}

	w.WriteHeader(http.StatusOK)
}

func TestFindUsersInvalidParameters(t *testing.T) {
	cases := []TestCase {
		{
			AccessToken: "token",
			Request: SearchRequest {
				Limit: -1,
				Offset: 20,
				Query: "on",
				OrderField: "Age",
				OrderBy: OrderByAsIs,
			},
			Result: nil,
			IsError: true,
			TextError: "limit must be > 0",
		},
		{
			AccessToken: "token",
			Request: SearchRequest {
				Limit: 0,
				Offset: -1,
				Query: "on",
				OrderField: "Age",
				OrderBy: OrderByAsIs,
			},
			Result: nil,
			IsError: true,
			TextError: "offset must be > 0",
		},
	}

	ts := httptest.NewServer(http.HandlerFunc(MockServer))
	defer ts.Close()

	for caseNum, item := range cases {
		client := SearchClient{AccessToken: item.AccessToken, URL: ts.URL}

		result, err := client.FindUsers(item.Request)
		if err != nil && err.Error() != item.TextError {
			t.Errorf("[%d] wrong type of error: expected %#v, got %#v", caseNum, item.TextError, err.Error())
		}
		if err != nil && !item.IsError {
			t.Errorf("[%d] unexpected error: %#v", caseNum, err)
		}
		if err == nil && item.IsError {
			t.Errorf("[%d] expected error, got nil", caseNum)
		}
		if !reflect.DeepEqual(item.Result, result) {
			t.Errorf("[%d] wrong result, expected %#v, got %#v", caseNum, item.Result, result)
		}
	}
}

func TestBrokenServer(t *testing.T) {
	cases := []TestCase {
		{
			AccessToken: "timeout_error_testing",
			Request: SearchRequest {
				Limit: 5,
				Offset: 0,
				Query: "on",
				OrderField: "Age",
				OrderBy: OrderByAsIs,
			},
			Result: nil,
			IsError: true,
			TextError: "timeout for limit=6&offset=0&order_by=0&order_field=Age&query=on",
		},
	}

	ts := httptest.NewServer(http.HandlerFunc(MockServer))
	defer ts.Close()

	for caseNum, item := range cases {
		client := SearchClient{AccessToken: item.AccessToken, URL: ts.URL}

		result, err := client.FindUsers(item.Request)
		if err != nil && err.Error() != item.TextError {
			t.Errorf("[%d] wrong type of error: expected %#v, got %#v", caseNum, item.TextError, err.Error())
		}
		if err != nil && !item.IsError {
			t.Errorf("[%d] unexpected error: %#v", caseNum, err)
		}
		if err == nil && item.IsError {
			t.Errorf("[%d] expected error, got nil", caseNum)
		}
		if !reflect.DeepEqual(item.Result, result) {
			t.Errorf("[%d] wrong result, expected %#v, got %#v", caseNum, item.Result, result)
		}
	}
}