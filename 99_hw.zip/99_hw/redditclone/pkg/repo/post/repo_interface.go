package repo

import "redditclone/pkg/post"

type PostRepo interface {
	GetAll() ([]post.Post, error)
	GetByID(id string) (post.Post, error)
	Add(post post.DataPost, login string, userID string) (post.Post, error)
	GetByCategory(category string) ([]post.Post, error)
	GetPostsByUsername(username string) ([]post.Post, error)
	DeletePostByID(postID, username string) error
	AddComment(postID, body, username, userID string) (post.Post, error)
	DeleteComment(postID, commentID, username string) (post.Post, error)
	VotePost(postID, userID string, voteDirection int) (post.Post, error)
}

type PostMemoryRepository struct {
	posts *mongo.Collection
}
