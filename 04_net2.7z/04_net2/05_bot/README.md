```
user1 - привет -> telegram

telegram -> bot-server (? привет)
         <- reply: привет

user1 - привет -> telegram
               <- привет
```

Telegram Bot API
https://core.telegram.org/bots/api#making-requests