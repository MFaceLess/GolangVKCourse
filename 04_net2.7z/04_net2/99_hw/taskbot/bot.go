package main

import (
	"context"
	"fmt"
	"strings"
)

type BotData struct {
	Bot     *BotAPI
	Updates tgbotapi.UpdatesChannel
}

const (
	tasksCommand    = "/tasks"
	newCommand      = "/new"
	assignCommand   = "/assign"
	unassignCommand = "/unassign"
	resolveCommand  = "/resolve"
	myCommand       = "/my"
	ownerCommand    = "/owner"
)

var (
	BotToken = "XXX"

	WebhookURL = "https://525f2cb5.ngrok.io"
)

func getUpdatesChanel() (*BotData, error) {
	bot, err := tgbotapi.NewBotAPI(*BotToken)
	if err != nil {
		return nil, fmt.Errorf("NewBotAPI failed: %s", err)
	}

	bot.Debug = true

	wh, err := tgbotapi.NewWebhook(*WebhookURL)
	if err != nil {
		return nil, fmt.Errorf("NewWebhook failed: %s", err)
	}

	_, err = bot.Request(wh)
	if err != nil {
		return nil, fmt.Errorf("SetWebhook failed: %s", err)
	}

	updates := bot.ListenForWebhook("/")

	botData := &BotData{
		Bot:     bot,
		Updates: updates,
	}

	return botData, nil
}

func processingUserMessage(bot *BotData, update tgbotapi.Update) {
	var messageToUser string

	if startsWith(update.Message.Text, tasksCommand) {
		messageToUser = getTasks()
	} else if startsWith(update.Message.Text, newCommand) {
		taskName := strings.Replace(update.Message.Text, newCommand, "", 1)
		messageToUser = createTask(taskName)
	} else if startsWith(update.Message.Text, assignCommand) {
		ID := strings.Replace(update.Message.Text, assignCommand+"_", "", 1)
		messageToUser = assignTask(ID)
	} else if startsWith(update.Message.Text, unassignCommand) {
		ID := strings.Replace(update.Message.Text, unassignCommand+"_", "", 1)
		messageToUser = unassignTask(ID)
	} else if startsWith(update.Message.Text, resolveCommand) {
		ID := strings.Replace(update.Message.Text, resolveCommand+"_", "", 1)
		messageToUser = resolveTask(ID)
	} else if startsWith(update.Message.Text, myCommand) {
		messageToUser = getMyTasks()
	} else if startsWith(update.Message.Text, ownerCommand) {
		messageToUser = getOwnTasks()
	}

	bot.Send(tgbotapi.NewMessage(
		update.Message.Chat.ID,
		messageToUser,
	))
}

func startTaskBot(ctx context.Context) error {
	botData, err := getUpdatesChanel()
	if err != nil {
		return err
	}

	for {
		select {
		case <-ctx.Done():
			return nil

		case update, ok := <-botData.Updates:
			if !ok {
				return nil
			}
			processingUserMessage(botData.Bot, update)
		}
	}
}

func main() {
	err := startTaskBot(context.Background())
	if err != nil {
		panic(err)
	}
}
