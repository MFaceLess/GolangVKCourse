package main

import (
	"strings"
)

func startsWith(src string, substr string) bool {
	if strings.Index(src, substr) == 0 {
		return true
	}
	return false
}
