package note

import (
	"errors"
	"slices"
	"strings"
	"sync"
	"time"
)

const (
	OrderById      = "id"
	OrderByText    = "text"
	OrderByCreated = "created_at"
	OrderByUpdated = "updated_at"
)

type NoteMemoryRepository struct {
	data   map[int]*Note
	lastID int
	*sync.RWMutex
}

func NewMemoryRepo() *NoteMemoryRepository {
	return &NoteMemoryRepository{
		data:    make(map[int]*Note, 10),
		RWMutex: &sync.RWMutex{},
	}
}

func (repo *NoteMemoryRepository) GetNote(id int) *Note {
	repo.RLock()
	defer repo.RUnlock()
	if note, ok := repo.data[id]; ok {
		return note
	}
	return nil
}

func (repo *NoteMemoryRepository) CreateNote(text string) *Note {
	repo.Lock()
	defer repo.Unlock()

	if repo.lastID == 0 {
		repo.lastID++
	}

	insertedNote := &Note{
		ID:        repo.lastID,
		Text:      text,
		CreatedAt: time.Now(),
		UpdatedAt: time.Now(),
	}

	repo.data[repo.lastID] = insertedNote
	repo.lastID += 1

	return insertedNote
}

func (repo *NoteMemoryRepository) UpdateNote(id int, text string) *Note {
	repo.Lock()
	defer repo.Unlock()

	_, ok := repo.data[id]
	if !ok {
		return nil
	}

	repo.data[id].Text = text
	repo.data[id].UpdatedAt = time.Now()

	return repo.data[id]
}

func (repo *NoteMemoryRepository) DeleteNote(id int) error {
	repo.Lock()
	defer repo.Unlock()

	_, ok := repo.data[id]
	if !ok {
		return errors.New("Note with this ID doesn't exist")
	}

	delete(repo.data, id)

	return nil
}

func (repo *NoteMemoryRepository) GetNotes(parameter string) []*Note {
	var notes []*Note

	repo.RLock()
	for _, note := range repo.data {
		notes = append(notes, note)
	}
	repo.RUnlock()

	switch parameter {
	case OrderById:
		slices.SortFunc(notes, func(a, b *Note) int {
			return a.ID - b.ID
		})
	case OrderByText:
		slices.SortFunc(notes, func(a, b *Note) int {
			return strings.Compare(a.Text, b.Text)
		})
	case OrderByCreated:
		slices.SortFunc(notes, func(a, b *Note) int {
			return a.CreatedAt.Compare(b.CreatedAt)
		})
	case OrderByUpdated:
		slices.SortFunc(notes, func(a, b *Note) int {
			return a.UpdatedAt.Compare(b.UpdatedAt)
		})

	}

	return notes
}
