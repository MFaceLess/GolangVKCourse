package main

import (
	"fmt"
	"slices"
	"strings"
)

const (
	notAssigned = ""
)

func getTasks(sender string) string {
	tasksIDs := []int{}

	tasksInfo.RLock()
	for taskID, _ := range tasksInfo.TasksNames {
		tasksIDs = append(tasksIDs, taskID)
	}
	tasksInfo.RUnlock()

	if len(tasksIDs) == 0 {
		return "Нет задач"
	}

	slices.Sort(tasksIDs)

	var result strings.Builder
	for i, ID := range tasksIDs {
		tasksInfo.RLock()
		taskName := tasksInfo.TasksNames[ID]
		taskCreator := tasksInfo.TasksCreators[ID]
		taskExecutor := tasksInfo.TasksAssignee[ID]
		tasksInfo.RUnlock()

		result.WriteString(fmt.Sprintf("%d. %s by %s\n", ID, taskName, taskCreator))

		switch taskExecutor {
		case notAssigned:
			result.WriteString(fmt.Sprintf("/assign_%d", ID))
		case sender:
			result.WriteString(fmt.Sprintf("assignee: я\n/unassign_%d /resolve_%d", ID, ID))
		default:
			result.WriteString(fmt.Sprintf("assignee: %s", taskExecutor))
		}

		if i+1 != len(tasksIDs) {
			result.WriteString("\n")
		}
	}

	return result.String()
}

func createTask(taskName string, sender string) string {
	var ID int

	taskCounter.Lock()
	taskCounter.TasksCounter += 1
	ID = taskCounter.TasksCounter
	taskCounter.Unlock()

	tasksInfo.Lock()
	tasksInfo.TasksNames[ID] = taskName
	tasksInfo.TasksCreators[ID] = sender
	tasksInfo.TasksAssignee[ID] = ""
	tasksInfo.Unlock()

	result := fmt.Sprintf("Задача \"%s\" создана, id=%d", taskName, ID)

	return result
}

func assignTask(ID int, sender string, bot *tgbotapi.BotAPI) string {
	var taskName string
	var ok bool

	tasksInfo.RLock()
	if taskName, ok = tasksInfo.TasksNames[ID]; !ok {
		tasksInfo.RUnlock()
		return "Нет такой задачи"
	}
	taskCreator := tasksInfo.TasksCreators[ID]
	tasksInfo.RUnlock()

	result := fmt.Sprintf("Задача \"%s\" назначена на вас")

	if taskCreator != sender {
		usersChats.RLock()
		creatorChatID := usersChats.UserChats[taskCreator]
		usersChats.RUnlock()

		messageToCreator := fmt.Sprintf("Задача \"%s\" назначена на %s", taskName, sender)

		bot.Send(tgbotapi.NewMessage(
			creatorChatID,
			messageToCreator,
		))
	}

	return result
}

func unassignTask(ID int, sender string, bot *tgbotapi.BotAPI) string {
	tasksInfo.Lock()
	if executor, ok := tasksInfo.TasksAssignee[ID]; !ok || executor != sender {
		tasksInfo.Unlock()
		return "Задача не на вас"
	}
	tasksInfo.TasksAssignee[ID] = ""
	tasksInfo.Unlock()

	tasksInfo.RLock()
	taskName := tasksInfo.TasksNames[ID]
	creator := tasksInfo.TasksCreators[ID]
	tasksInfo.RUnlock()

	usersChats.RLock()
	creatorChatID := usersChats.UserChats[creator]
	usersChats.RUnlock()

	messageToCreator := fmt.Sprintf("Задача \"%s\" осталась без исполнителя", taskName)
	bot.Send(tgbotapi.NewMessage(
		creatorChatID,
		messageToCreator,
	))

	return "Принято"
}

func resolveTask(ID int, sender string, bot *tgbotapi.BotAPI) string {
	tasksInfo.Lock()
	if executor, ok := tasksInfo.TasksAssignee[ID]; !ok || executor != sender {
		tasksInfo.Unlock()
		return "Задача не на вас"
	}
	delete(tasksInfo.TasksAssignee, ID)
	taskName := tasksInfo.TasksNames[ID]
	creator := tasksInfo.TasksCreators[ID]
	delete(tasksInfo.TasksNames, ID)
	delete(tasksInfo.TasksCreators, ID)
	tasksInfo.Unlock()

	usersChats.RLock()
	creatorChatID := usersChats.UserChats[creator]
	usersChats.RUnlock()

	messageToCreator := fmt.Sprintf("Задача \"%s\" выполнена %s", taskName, sender)
	bot.Send(tgbotapi.NewMessage(
		creatorChatID,
		messageToCreator,
	))

	return fmt.Sprintf("Задача \"%s\" выполнена", taskName)
}

func getMyTasks(sender string) string {
	tasksIDs := []int{}

	tasksInfo.RLock()
	for taskID, taskExecutor := range tasksInfo.TasksAssignee {
		if taskExecutor == sender {
			tasksIDs = append(tasksIDs, taskID)
		}
	}
	tasksInfo.RUnlock()

	slices.Sort(tasksIDs)

	var result strings.Builder
	for i, ID := range tasksIDs {
		tasksInfo.RLock()
		taskName := tasksInfo.TasksNames[ID]
		tasksInfo.RUnlock()

		result.WriteString(fmt.Sprintf("%d. %s by %s\n/unassign_%d /resolve_%d", ID, taskName, sender, ID, ID))
		if i+1 != len(tasksIDs) {
			result.WriteString("\n")
		}
	}

	return result.String()
}

func getOwnTasks(sender string) string {
	tasksIDs := []int{}

	tasksInfo.RLock()
	for taskID, taskCreator := range tasksInfo.TasksCreators {
		if taskCreator == sender {
			tasksIDs = append(tasksIDs, taskID)
		}
	}
	tasksInfo.RUnlock()

	slices.Sort(tasksIDs)

	var result strings.Builder
	for i, ID := range tasksIDs {
		tasksInfo.RLock()
		taskName := tasksInfo.TasksNames[ID]
		tasksInfo.RUnlock()

		result.WriteString(fmt.Sprintf("%d. %s by %s\n/assign_%d", ID, taskName, sender, ID))
		if i+1 != len(tasksIDs) {
			result.WriteString("\n")
		}
	}

	return result.String()
}
