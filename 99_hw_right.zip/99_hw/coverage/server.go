package main

import (
	"io/ioutil"
	"net/http"
	"encoding/xml"
	"encoding/json"
	"strconv"
	"errors"
	"strings"
	"cmp"
	"slices"
)

const (
	LimitNotSet = -1
)

var (
	DataFileName = "dataset.xml"

	errAccessDenied = errors.New("Access Denied")

	errInvalidOrder = errors.New("Некорректно задано поле order")
	errInvalidLimit = errors.New("Некорректно задано поле limit")
	errInvalidOffset = errors.New("Некорректно задано поле offset")
)

type UserXMLData struct {
	ID int `xml:"id"`
	FirstName string `xml:"first_name"`
	LastName string	`xml:"last_name"`
	Age int `xml:"age"`
	About string `xml:"about"`
	Gender string `xml:"gender"`
}

func (user *UserXMLData) MarshalJSON() ([]byte, error) {
	serializeMap := map[string]interface{} {
		"ID": user.ID,
		"Name": user.FirstName + " " + user.LastName,
		"Age": user.Age,
		"About": user.About,
		"Gender": user.Gender,
	}

	return json.Marshal(serializeMap)
}

type Users struct {
	UserList []UserXMLData `xml:"row"`
}

func GetFileData(fileName string) ([]byte, error) {
	fContent, err := ioutil.ReadFile(fileName)
	
	if err != nil {
		return nil, err
	}

	return fContent, nil
}

func OrderUsers(users *[]UserXMLData, orderField string, orderBy int) {
	if orderBy == OrderByAsIs {
		return
	}

	slices.SortFunc(*users, func(a, b UserXMLData) int {
		var result int
		switch orderField {
		case "Id":
			result = cmp.Compare(a.ID, b.ID)
		case "Age":
			result = cmp.Compare(a.Age, b.Age)
		default:
			result = strings.Compare(a.FirstName + " " + a.LastName, b.FirstName + " " + b.LastName)
		}

		if orderBy == OrderByDesc {
			return -result
		}
		return result
	})
}

func ApplyQueryToUsers(request *SearchRequest, users *Users) []UserXMLData {
	queryUsers := []UserXMLData{}

	if (request.Query != "") {
		for _, user := range users.UserList {
			if strings.Contains(user.FirstName + " " + user.LastName, request.Query) || strings.Contains(user.About, request.Query) {
				queryUsers = append(queryUsers, user)
			}
		}
	} else {
		queryUsers = users.UserList
	}

	OrderUsers(&queryUsers, request.OrderField, request.OrderBy)

	if request.Offset < len(queryUsers) && request.Offset+request.Limit <= len(queryUsers) {
		return queryUsers[request.Offset:(request.Offset+request.Limit)]
	} else if (request.Offset < len(queryUsers)) {
		return queryUsers[request.Offset:]
	}
	return []UserXMLData{}
	
}

func SearchServer(w http.ResponseWriter, r *http.Request) {
	token := r.Header.Get("AccessToken")
	if token == "" {
		http.Error(w, errAccessDenied.Error(), http.StatusUnauthorized)
		return
	}

	orderField := r.URL.Query().Get("order_field")
	if orderField == "" {
		orderField = "Name"
	}
	if orderField != "Name" && orderField != "Id" && orderField != "Age" {
		err := SearchErrorResponse{Error: ErrorBadOrderField}
		w.WriteHeader(http.StatusBadRequest)
		json.NewEncoder(w).Encode(err)
		return
	}

	var err error

	orderString := r.URL.Query().Get("order_by")
	var order int
	if orderString != "" {
		order, err = strconv.Atoi(orderString)
		if err != nil || (order != OrderByAsc && order != OrderByAsIs && order != OrderByDesc) {
			err := SearchErrorResponse{Error: errInvalidOrder.Error()}
			w.WriteHeader(http.StatusBadRequest)
			json.NewEncoder(w).Encode(err)
			return
		}
	}

	limitString := r.URL.Query().Get("limit")
	limit := LimitNotSet
	if limitString != "" {
		limit, err = strconv.Atoi(limitString)
		if err != nil {
			err := SearchErrorResponse{Error: errInvalidLimit.Error()}
			w.WriteHeader(http.StatusBadRequest)
			json.NewEncoder(w).Encode(err)
			return
		}
	}

	offsetString := r.URL.Query().Get("offset")
	var offset int
	if offsetString != "" {
		offset, err = strconv.Atoi(offsetString)
		if err != nil {
			err := SearchErrorResponse{Error: errInvalidOffset.Error()}
			w.WriteHeader(http.StatusBadRequest)
			json.NewEncoder(w).Encode(err)
			return
		}
	}
	
	query := r.URL.Query().Get("query")

	xmlData, err := GetFileData(DataFileName)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	users := new(Users)
	err = xml.Unmarshal(xmlData, &users)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	searchRequest := SearchRequest{
		Limit: limit,
		Offset: offset,
		Query: query,
		OrderField: orderField,
		OrderBy: order,
	}

	usersResult := ApplyQueryToUsers(&searchRequest, users)

	w.Header().Set("Content-Type", "application/json")
	err = json.NewEncoder(w).Encode(usersResult)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
}