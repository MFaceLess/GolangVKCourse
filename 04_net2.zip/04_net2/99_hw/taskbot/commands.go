package main

func getTasks() string {

}

func createTask(taskName string) string {

}

func assignTask(ID string) string {

}

func unassignTask(ID string) string {

}

func resolveTask(ID string) string {

}

func getMyTasks() string {

}

func getOwnTasks() string {

}
