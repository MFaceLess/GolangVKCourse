package main

import (
	"fmt"
)

func getTasks() string {

}

func createTask(taskName string, sender string) string {
	var ID int

	taskCounter.Lock()
	taskCounter.TasksCounter += 1
	ID = taskCounter.TasksCounter
	taskCounter.Unlock()

	tasksInfo.Lock()
	tasksInfo.TasksNames[ID] = taskName
	tasksInfo.TasksCreators[ID] = sender
	tasksInfo.TasksAssignee[ID] = ""
	tasksInfo.Unlock()

	result := fmt.Sprintf("Задача \"%s\" создана, id=%d", taskName, ID)

	return result
}

func assignTask(ID string) string {

}

func unassignTask(ID int, sender string, bot *tgbotapi.BotAPI) string {
	tasksInfo.Lock()
	if executor, ok := tasksInfo.TasksAssignee[ID]; !ok || executor != sender {
		return "Задача не на вас"
	}
	tasksInfo.TasksAssignee[ID] = ""
	tasksInfo.Unlock()

	tasksInfo.RLock()
	taskName := tasksInfo.TasksNames[ID]
	creator := tasksInfo.TasksCreators[ID]
	tasksInfo.RUnlock()

	usersChats.RLock()
	creatorChatID := usersChats.UserChats[creator]
	usersChats.RUnlock()

	messageToCreator := fmt.Sprintf("Задача \"%s\" осталась без исполнителя", taskName)
	bot.Send(tgbotapi.NewMessage(
		creatorChatID,
		messageToCreator,
	))

	return "Принято"
}

func resolveTask(ID string) string {

}

func getMyTasks() string {

}

func getOwnTasks() string {

}
