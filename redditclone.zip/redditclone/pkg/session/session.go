package session

import (
	"encoding/json"
	"os"
	"time"

	jwt "github.com/dgrijalva/jwt-go"
)

type Claims struct {
	Username string `json:"username"`
	UserID   string `json:"id"`
	jwt.StandardClaims
}

type Config struct {
	JwtSecretKey []byte
}

func GenerateJWT(username, userID string) (string, error) {
	expirationTime := time.Now().Add(24 * time.Hour)
	claims := &Claims{
		Username: username,
		UserID:   userID,
		StandardClaims: jwt.StandardClaims{
			ExpiresAt: expirationTime.Unix(),
		},
	}

	jwtKey, err := ReadJWTSecretKey()
	if err != nil {
		return "", err
	}

	token := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)
	tokenString, err := token.SignedString(jwtKey.JwtSecretKey)
	if err != nil {
		return "", nil
	}
	return tokenString, nil
}

func ReadJWTSecretKey() (*Config, error) {
	filePath := os.Getenv("FilePath")
	if filePath == "" {
		filePath = "./config.json"
	}

	data, err := os.ReadFile(filePath)
	if err != nil {
		return nil, err
	}

	var config struct {
		JwtSecretKey string `json:"jwtSecretKey"`
	}

	err = json.Unmarshal(data, &config)
	if err != nil {
		return nil, err
	}

	return &Config{JwtSecretKey: []byte(config.JwtSecretKey)}, nil
}
