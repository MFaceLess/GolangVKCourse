package post

import (
	"crypto/rand"
	"fmt"
	"slices"
	"sync"
	"time"
)

type PostMemoryRepository struct {
	data map[string]*Post
	*sync.RWMutex
}

func NewMemoryRepo() *PostMemoryRepository {
	return &PostMemoryRepository{
		data:    make(map[string]*Post, 10),
		RWMutex: &sync.RWMutex{},
	}
}

func (repo *PostMemoryRepository) GetAll() []*Post {
	var items []*Post

	repo.RLock()
	for _, post := range repo.data {
		items = append(items, post)
	}
	repo.RUnlock()

	slices.SortFunc(items, func(a, b *Post) int {
		return b.Score - a.Score
	})

	return items
}

func (repo *PostMemoryRepository) GetByID(id string) *Post {
	repo.RLock()
	defer repo.RUnlock()
	return repo.data[id]
}

func (repo *PostMemoryRepository) Add(postData DataPost, login string, userID string) *Post {
	randID := make([]byte, 16)
	rand.Read(randID)

	post := &Post{
		Score: 1,
		Views: 0,
		Type:  postData.Type,
		Title: postData.Title,
		Author: Author{
			Username: login,
			ID:       userID,
		},
		Category: postData.Category,
		Votes: []Vote{
			{
				User: userID,
				Vote: 1,
			},
		},
		Comments:         []Comment{},
		Created:          time.Now().UTC().Format(time.RFC3339Nano),
		UpvotePercentage: 100,
		ID:               fmt.Sprintf("%x", randID),
		Url:              postData.Url,
		Text:             postData.Text,
	}

	repo.Lock()
	repo.data[post.ID] = post
	repo.Unlock()

	return post
}

func (repo *PostMemoryRepository) GetByCategory(category string) []*Post {
	var items []*Post

	repo.RLock()
	for _, post := range repo.data {
		if post.Category == category {
			items = append(items, post)
		}
	}
	repo.RUnlock()

	slices.SortFunc(items, func(a, b *Post) int {
		return b.Score - a.Score
	})

	return items
}
