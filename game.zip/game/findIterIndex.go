package main


func FindItem(array any, needFindObj string) int {
	switch arr := array.(type) {
	case []*Item:
		for i, item := range arr {
			if item.Name == needFindObj {
				return i
			}
		}
	case map[*Item]struct{}:
		for key, _ := range arr {
			if key.Name == needFindObj {
				return 1
			}
		}
	}

	return -1
}