package main

import (
	"strings"
)

type User struct {
	Position *Room
	Items map[*Item]struct{}
}

func (u *User) SetPosition(room *Room) {
	u.Position = room
}

func (u *User) TakeItem(item string) bool {
	itemIndex := FindItem(u.Position.Items, item)
	if itemIndex == -1 {
		return false
	}
	u.Items[u.Position.Items[itemIndex]] = struct{}{}
	u.Position.Items = append(u.Position.Items[:itemIndex], u.Position.Items[itemIndex + 1:]...) //Исключаем элемент из окружения
	return true
}

func (u *User) ClearItems() {
	u.Items = make(map[*Item]struct{})
}

func (u *User) DoCommand(command string, parameters ...string) string {
	var result string
	
	switch command {
	
	case "осмотреться":
		result = u.HandleLookAround(parameters...)
	case "идти":
		result = u.HandleWalk(parameters[0], parameters[1:]...)
	case "надеть", "взять":
		result = u.HandleTakeItem(command, parameters[0], parameters[1:]...)
	case "применить":
		result = u.HandleApply(parameters[0], parameters[1], parameters[2:]...)
	default:
		result = "неизвестная команда"

	}

	return result
}

func (u *User) HandleApply(what string, toWhat string, _ ...string) string {
	var result strings.Builder
	var item *Item
	for key, _ := range u.Items {
		if key.Name == what {
			item = key
			break
		}
	}
	if item == nil {
		return "нет предмета в инвентаре" + " - " + what
	}

	if (item.UseItem != nil) {
		resultUsage := item.UseItem(toWhat, u)
		if (resultUsage == "") {
			result.WriteString("не к чему применить")
		} else {
			result.WriteString(resultUsage)
		}
	}

	return result.String()
}

func (u *User) HandleTakeItem(command string, what string, _ ...string) string {
	storeName := "рюкзак"
	checkStore := FindItem(u.Items, storeName)
	if checkStore == -1 && what != storeName {
		return "некуда класть"
	}

	isItemTaken := u.TakeItem(what)
	if !isItemTaken {
		return "нет такого"
	}

	var result strings.Builder
	switch command {
	case "надеть":
		result.WriteString("вы надели")
	case "взять":
		result.WriteString("предмет добавлен в инвентарь")
	}
	result.WriteString(": " + what)
	return result.String()
}

func (u *User) HandleLookAround(_ ...string) string {
	var result strings.Builder
	if len(u.Position.Items) > 0 {
		result.WriteString(u.Position.Description)
	} else {
		result.WriteString("пустая комната")		
	}
	result.WriteString(DisplayItems(u))
	result.WriteString(DisplayRoomTarget(u))
	result.WriteString(DisplayPossibleMoves(u))
	return result.String()
}

func (u *User) HandleWalk(where string, _ ...string) string {
	//Проверка, что можно пройти
	isDoorOpen, exists := u.Position.ConnectionsSet[gameMap.Rooms[where]]
	if !exists {
		return "нет пути в " + where
	}
	if !isDoorOpen {
		return "дверь закрыта"
	}

	u.SetPosition(gameMap.Rooms[where]) //Меняем текущую позицию игрока

	var result strings.Builder
	result.WriteString(u.Position.WalkDescription)
	result.WriteString(DisplayPossibleMoves(u))
	
	return result.String()
}


func DisplayPossibleMoves(u *User) string {
	var builder strings.Builder
	builder.WriteString(". можно пройти - ")
	for i, room := range u.Position.Connections {
		if u.Position.IsOutsideHome {
			builder.WriteString("домой")
		} else {
			builder.WriteString(room.Name)
		}
		if i < len(u.Position.Connections) - 1 {
			builder.WriteString(", ")
		}
	}
	return builder.String()
}

func DisplayItems(u *User) string {
	var builder strings.Builder
	var itemPlace string
	if len(u.Position.Items) > 0 {
		itemPlace = u.Position.Items[0].ItemPosition
		builder.WriteString(u.Position.Items[0].ItemPosition + ": ")
		for i, item := range u.Position.Items {
			if item.ItemPosition != itemPlace {
				builder.WriteString(item.ItemPosition + ": ")
			}
			builder.WriteString(item.Name)
			if i < len(u.Position.Items) - 1 {
				builder.WriteString(", ")
			}
		}
	}
	return builder.String()
}

func DisplayRoomTarget(u *User) string {
	var builder strings.Builder
	if len(u.Position.RoomTarget) > 0 {
		builder.WriteString(", надо ")
		for i, item := range u.Position.RoomTarget {
			if _, ok := u.Items[item]; ok {
				continue
			}
			builder.WriteString(item.ItemAction + " " + item.Name)
			if i < len(u.Position.RoomTarget) - 1 {
				builder.WriteString(" и ")
			}
		}
	}
	return builder.String()
}