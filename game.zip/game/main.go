package main


import (
	"fmt"
	"strings"
	"bufio"
	"os"
)


var user User
var gameMap Map

func main() {
	initGame()
	scanner := bufio.NewScanner(os.Stdin)
	for scanner.Scan() {
		line := scanner.Text()
		if line == "exit" {
			break
		}
		fmt.Println(handleCommand(line))
	}
}

func initGame() {
	var kitchen Room
	var corridor Room
	var street Room
	var appartment Room

	tea := Item {
		Name: "чай",
		ItemPosition: "на столе",
	}

	key := Item {
		Name: "ключи",
		ItemPosition: "на столе",

		UseItem: func(toWhat string, u *User) string {
			var result strings.Builder
			switch toWhat {
			case "дверь":
				result.WriteString(toWhat + " " + "открыта")
				for key, _ := range u.Position.ConnectionsSet {
					u.Position.ConnectionsSet[key] = true
				}
			}

			return result.String()
		},
	}

	univer := Item {
		Name: "универ",
		ItemAction: "идти в",
	}

	notes := Item {
		Name: "конспекты",
		ItemPosition: "на столе",
	}

	backpack := Item {
		Name: "рюкзак",
		ItemAction: "собрать",
		ItemPosition: "на стуле",
	}

	corridor = Room {
		Name: "коридор",
		WalkDescription: "ничего интересного",
		Connections: []*Room{&kitchen, &appartment, &street},
		ConnectionsSet: map[*Room]bool {
			&kitchen: true,
			&appartment: true,
			&street: false,
		}, 
	}

	street = Room {
		Name: "улица",
		WalkDescription: "на улице весна",
		Connections: []*Room{&corridor},
		ConnectionsSet: map[*Room]bool {
			&corridor: false,
		}, 
		IsOutsideHome: true,
	}

	appartment = Room {
		Name: "комната",
		WalkDescription: "ты в своей комнате",
		Connections: []*Room{&corridor},
		ConnectionsSet: map[*Room]bool {
			&corridor: true,
		}, 

		Items: []*Item{&key, &notes, &backpack},
	}

	kitchen = Room {
		Name: "кухня",
		Description: "ты находишься на кухне, ",
		RoomTarget: []*Item{&backpack, &univer}, //Цели в текущей комнате
		WalkDescription: "кухня, ничего интересного",

		Items: []*Item{&tea},
		Connections: []*Room{&corridor},
		ConnectionsSet: map[*Room]bool {
			&corridor: true,
		},

		IsOutsideHome: false,
	}

	user.SetPosition(&kitchen)
	user.ClearItems()

	gameMap.ClearMap()
	gameMap.AddRoom(&corridor)
	gameMap.AddRoom(&kitchen)
	gameMap.AddRoom(&appartment)
	gameMap.AddRoom(&street)

}

func handleCommand(command string) string {
	parameters := strings.Split(command, " ")
	cmd := parameters[0]
	args := parameters[1:]
	return user.DoCommand(cmd, args...)
}
