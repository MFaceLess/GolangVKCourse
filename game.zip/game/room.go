package main


type Room struct {
	Name string
	Description string
	WalkDescription string

	RoomTarget []*Item

	Connections []*Room
	ConnectionsSet map[*Room]bool //Учитывается возможность прохода из одной комнаты в другую

	Items []*Item
	IsOutsideHome bool
}