package main


type Item struct {
	Name string
	CanApply map[string]struct{}
	ItemAction string
	ActionResult string
	ItemPosition string

	UseItem func(string, *User) string
}