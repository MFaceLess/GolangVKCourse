package main


type Map struct {
	Rooms map[string]*Room
}

func (m *Map) ClearMap() {
	m.Rooms = make(map[string]*Room)
}

func (m *Map) AddRoom(r *Room) {
	m.Rooms[r.Name] = r
}