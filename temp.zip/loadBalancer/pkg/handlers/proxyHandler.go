package handlers

import (
	"log"
	"net/http"
	"net/http/httputil"

	"loadBalancer/pkg/backend"
)

func SetupProxyHandler(pool *backend.BackendPool) http.Handler {
	proxy := &httputil.ReverseProxy{
		Rewrite: func(r *httputil.ProxyRequest) {
			b := pool.NextBackend()
			log.Println("wee-wee", b)
			if b == nil {
				return
			}

			r.SetXForwarded()
			r.SetURL(b.URL)
		},
		// Director: func(req *http.Request) {
		// 	b := pool.NextBackend()
		// 	log.Println("wee-wee", b)
		// 	if b == nil {
		// 		return
		// 	}

		// 	req.URL.Scheme = b.URL.Scheme
		// 	req.URL.Host = b.URL.Host
		// },
		ErrorHandler: func(w http.ResponseWriter, r *http.Request, err error) {
			log.Printf("Proxy error: %v", err)
			http.Error(w, "Service unavailable", http.StatusServiceUnavailable)
		},
	}

	handler := &handler{proxy: proxy}

	return handler
}

type handler struct {
	proxy *httputil.ReverseProxy
}

func (h *handler) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	h.proxy.ServeHTTP(w, r)
}
