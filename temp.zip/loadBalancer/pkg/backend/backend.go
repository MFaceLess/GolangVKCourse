package backend

import (
	"context"
	"fmt"
	"log"
	"math/rand"
	"net/http"
	"net/url"
	"sort"
	"sync"
	"sync/atomic"
	"time"
)

type Backend struct {
	URL        *url.URL
	Alive      bool
	ActiveConn int64
	*sync.RWMutex
}

func (b *Backend) SetAlive(alive bool) {
	b.Lock()
	b.Alive = alive
	b.Unlock()
	log.Printf("Backend %s alive=%t", b.URL, alive)
}
func (b *Backend) IncConn()         { atomic.AddInt64(&b.ActiveConn, 1) }
func (b *Backend) DecConn()         { atomic.AddInt64(&b.ActiveConn, -1) }
func (b *Backend) ConnCount() int64 { return atomic.LoadInt64(&b.ActiveConn) }
func (b *Backend) IsAlive() bool {
	b.RLock()
	defer b.RUnlock()
	return b.Alive
}

type BackendPool struct {
	Backends []*Backend
	Strategy BalancerStrategy
	*sync.RWMutex
}

func NewBackendPool(urls []string) *BackendPool {
	pool := &BackendPool{RWMutex: &sync.RWMutex{}}
	for _, u := range urls {
		parsed, err := url.Parse(u)
		if err != nil {
			// Можно сделать, поскольку выполняется при инициализации приложения
			log.Fatalf("Неверный URL бэкэнда: %s", u)
		}
		b := &Backend{URL: parsed, Alive: true, RWMutex: &sync.RWMutex{}}
		pool.Backends = append(pool.Backends, b)
	}
	return pool
}

func (p *BackendPool) NextBackend() *Backend {
	fmt.Println("1")
	p.RLock()
	if p.Strategy == nil {
		fmt.Println("2")
		return nil
	}
	p.RUnlock()
	fmt.Println("3")
	fmt.Println(p.Strategy)
	return p.Strategy.NextBackend(p)
}

func (p *BackendPool) getAliveBackends() []*Backend {
	var alive []*Backend

	fmt.Println("cock")

	p.RLock()
	fmt.Println("cock1")
	backends := make([]*Backend, len(p.Backends))
	fmt.Println("cock2")
	copy(backends, p.Backends)
	fmt.Println("cock3")
	p.RUnlock()

	fmt.Println("dick")

	for _, b := range backends {
		if b.IsAlive() {
			alive = append(alive, b)
		}
	}

	return alive
}

func (p *BackendPool) SetStrategy(s BalancerStrategy) {
	p.Lock()
	p.Strategy = s
	p.Unlock()
}

func (p *BackendPool) HealthCheck(ctx context.Context, interval time.Duration) {
	ticker := time.NewTicker(interval)
	defer ticker.Stop()

	for {
		select {
		case <-ctx.Done():
			log.Printf("HealthCheck stopped: %v", ctx.Err())
			return
		case <-ticker.C:
			p.RLock()
			backends := make([]*Backend, len(p.Backends))
			copy(backends, p.Backends)
			p.RUnlock()

			for _, b := range backends {
				go func(b *Backend) {
					client := http.Client{Timeout: 2 * time.Second}
					_, err := client.Get(b.URL.String())
					alive := err == nil
					b.SetAlive(alive)
				}(b)
			}

		}
	}
}

// Реализуем паттерн Стратегия, чтобы в runtime можно было подменять при необходимости алгоритм выбора сервера
type BalancerStrategy interface {
	NextBackend(pool *BackendPool) *Backend
}

type RoundRobinStrategy struct {
	counter uint64
}

func (r *RoundRobinStrategy) NextBackend(pool *BackendPool) *Backend {
	fmt.Println("5555555")
	alive := pool.getAliveBackends()
	fmt.Println(alive)
	if len(alive) == 0 {
		fmt.Println("444")
		return nil
	}
	idx := int(atomic.AddUint64(&r.counter, 1)) % len(alive)
	fmt.Println(alive)
	fmt.Println(idx)
	return alive[idx]
}

type RandomStrategy struct{}

func (r *RandomStrategy) NextBackend(pool *BackendPool) *Backend {
	fmt.Println("6666")

	alive := pool.getAliveBackends()
	if len(alive) == 0 {
		return nil
	}
	return alive[rand.Intn(len(alive))]
}

type LeastConnectionsStrategy struct{}

func (l *LeastConnectionsStrategy) NextBackend(pool *BackendPool) *Backend {
	fmt.Println("7777777")

	alive := pool.getAliveBackends()
	if len(alive) == 0 {
		return nil
	}
	sort.Slice(alive, func(i, j int) bool {
		return alive[i].ConnCount() < alive[j].ConnCount()
	})

	return alive[0]
}
